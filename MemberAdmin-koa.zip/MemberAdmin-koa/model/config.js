/**
 * Created by Administrator on 2018/3/17 0017.
 */
/*配置文件*/


var app={

    dbUrl: 'mongodb://localhost:27017/',

    dbName: 'koa-member'

}

module.exports=app;